﻿export { Spieler };
 class Spieler
{
    name;
    token;
    color;
}